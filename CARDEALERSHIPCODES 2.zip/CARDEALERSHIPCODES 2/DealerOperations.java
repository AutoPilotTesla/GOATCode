public interface DealerOperations {
    void buyVehicle(Vehicle v);
    void sellVehicle(Vehicle v);
    void serviceVehicle(Vehicle v);
}
